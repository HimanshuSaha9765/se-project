<?php
namespace App\Repository;

use App\Exceptions\Handler;
use Illuminate\Http\Request;

interface EmployeeRepo{
    public function dashboard();
}

