@extends('installer.intsaller_layout')

@section('page-title')
    Add Completion Images
@endsection

@section('title')
    Add Completion Images
@endsection

@section('content')
    <h1>add_completion_images</h1>
@endsection
